# -*- coding: utf-8 -*-
"""
Created on Thu Nov 29 22:04:24 2020

@author: James
"""
from pytest import approx
from calculations_functions import calc_mean, calc_sdv, calc_mode, calc_min, calc_max, calc_median, calc_sdv, calc_median_skewness, calc_mode_skewness

def test_calc_mean():
    assert calc_mean([1,2,3]) == 2
    assert calc_mean([4,2,3,3]) == 3
    
def test_calc_sdv():
    assert calc_sdv([10, 12, 23, 23, 16, 23, 21, 16]) == approx(4.8989, 0.04)
    assert calc_sdv([234, 5443, 1 ,10, 12, 23, 23]) == approx(1888.52, 0.02)

def test_calc_mode():
    assert calc_mode([1,1,1,2,3,4,5]) == 1
    assert calc_mode([6,6,6,6,1,2,3,4,5,5]) == 6

def test_calc_min():
    assert calc_min([1,2,3,4,5]) == 1
    assert calc_min([10,1,23231,3,4,5,0]) == 0
    
def test_calc_max():
    assert calc_max([1,2,3,4,5]) == 5
    assert calc_max([10,1,23231,3,4,5,0]) == 23231
    
def test_calc_median():
    assert calc_median([1,2,3,4,5]) == 3
    assert calc_median([2,2,4,6,6,6]) == 5
    
def test_calc_median_skewness():
    assert calc_median_skewness([3,8,19,17,24,27]) == approx(0.1166, 0.04)